package net.ccbluex.liquidbounce.features.module.modules.render.DMGPUtil;

/**
 * Skid by Paimon.
 *
 * @Date 2022/10/2
 */
public class Particles {
    public int ticks = 1;
    public Location location;
    public String text;

    public Particles(Location location, String text) {
        this.location = location;
        this.text = text;
    }
}