/*
 * LiquidBounce+ Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.ResourceLocation


@ModuleInfo(name = "Cape", description = "Cape",Chinese="披风", category = ModuleCategory.RENDER)
class Cape : Module() {

    val styleValue = ListValue("Style", arrayOf("skidsense","Lunar","Bilibili","LiquidBounce","Paimon","JiaRan","Stars","RQ","Bilibilitv","huoying","KatterSense"), "skidsense")

    fun getCapeLocation(value: String): ResourceLocation {
        return try {
            CapeStyle.valueOf(value.toUpperCase()).location
        } catch (e: IllegalArgumentException) {
            CapeStyle.PAIMON.location
        }
    }

    enum class CapeStyle(val location: ResourceLocation) {
        LUNAR(ResourceLocation("skidsense/cape/lunar.png")),
        BILIBILI(ResourceLocation("skidsense/cape/biliBili.png")),
        LIQUIDBOUNCE(ResourceLocation("skidsense/cape/liquidbounce.png")),
        PAIMON(ResourceLocation("skidsense/cape/paimon.png")),
        JIARAN(ResourceLocation("skidsense/cape/jiaran.png")),
        STAR(ResourceLocation("skidsense/cape/star.png")),
        RQ(ResourceLocation("skidsense/cape/rq.png")),
        BILIBILITV(ResourceLocation("skidsense/cape/bilibilitv.png")),
        HUOYING(ResourceLocation("skidsense/cape/huoying.png")),
        SKYRIM(ResourceLocation("skidsense/cape/skidsense.png")),
        KATTERSENSE(ResourceLocation("kattersense/cape/ks.png"))
    }

    override val tag: String
        get() = styleValue.get()
}