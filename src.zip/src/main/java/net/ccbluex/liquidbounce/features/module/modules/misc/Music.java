package net.ccbluex.liquidbounce.features.module.modules.misc;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
/**
 * Skid by Paimon.
 *
 * @Date 2022/8/27
 */
@ModuleInfo(name = "Music", description = "play music",Chinese="音乐播放器", category = ModuleCategory.MISC)
public class Music extends Module {
}
