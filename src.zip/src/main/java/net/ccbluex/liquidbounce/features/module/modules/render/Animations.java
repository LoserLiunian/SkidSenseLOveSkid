
package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;


@ModuleInfo(name = "Animations", description = "Animations", Chinese = "动画",category = ModuleCategory.RENDER)
public class Animations extends Module {
    public static FloatValue itemPosX = new FloatValue("itemPosX", 0, -1, 1);
    public static FloatValue itemPosY = new FloatValue("itemPosY", 0, -1, 1);
    public static FloatValue itemPosZ = new FloatValue("itemPosZ", 0, -1, 1);
    public static FloatValue Scale = new FloatValue("Scale", 1, 0, 2);

    public static final BoolValue RotateItems = new BoolValue("Rotate-Items", false);



}
