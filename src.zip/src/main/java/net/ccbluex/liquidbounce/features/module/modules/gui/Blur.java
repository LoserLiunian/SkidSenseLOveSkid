/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.shader.Framebuffer
 */

package net.ccbluex.liquidbounce.features.module.modules.gui;

import net.ccbluex.liquidbounce.utils.render.blur.BloomUtil;
import net.ccbluex.liquidbounce.utils.render.blur.GaussianBlur;
import net.ccbluex.liquidbounce.utils.render.blur.KawaseBlur;
import net.ccbluex.liquidbounce.utils.render.blur.StencilUtil;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.shader.Framebuffer;

@ModuleInfo(name="Blur", description = "SB", Chinese = "模糊", category = ModuleCategory.GUI)
public class Blur
extends Module {
    private final BoolValue blur = new BoolValue("Blur", true);
    private final ListValue blurMode = new ListValue("Blur Mode", new String[]{"Kawase", "Gaussian"}, "Kawase");
    private final IntegerValue radius = new IntegerValue("Blur Radius", 10, 1, 50);
    private final IntegerValue iterations = new IntegerValue("Blur Iterations", 4, 15, 1);
    private final IntegerValue offset = new IntegerValue("Blur Offset", 3, 1, 20);
    private final BoolValue shadow = new BoolValue("Shadow", true);
    private final IntegerValue shadowRadius = new IntegerValue("Shadow Radius", 6, 1, 20);
    private final IntegerValue shadowOffset = new IntegerValue("Shadow Offset", 2, 1, 15);
    private String currentMode;
    private Framebuffer bloomFramebuffer = new Framebuffer(1, 1, false);

    @Override
    public void onEnable() {
        this.currentMode = this.blurMode.get();
    }

    @EventTarget
    public void Render2D(Render2DEvent e) {
        this.blurScreen();
    }

    public void stuffToBlur(boolean bloom) {
    }

    public void blurScreen() {
        if (!this.getState()) {
            return;
        }
        if (!this.currentMode.equals(this.blurMode.get())) {
            this.currentMode = this.blurMode.get();
        }
        if (this.blur.get().booleanValue()) {
            StencilUtil.initStencilToWrite();
            this.stuffToBlur(false);
            StencilUtil.readStencilBuffer(1);
            switch (this.currentMode) {
                case "Gaussian": {
                    GaussianBlur.renderBlur(this.radius.get());
                    break;
                }
                case "Kawase": {
                    KawaseBlur.renderBlur(this.iterations.get(), this.offset.get());
                }
            }
            StencilUtil.uninitStencilBuffer();
        }
        if (this.shadow.get().booleanValue()) {
            this.bloomFramebuffer = RenderUtils.createFrameBuffer(this.bloomFramebuffer);
            this.bloomFramebuffer.framebufferClear();
            this.bloomFramebuffer.bindFramebuffer(true);
            this.stuffToBlur(true);
            this.bloomFramebuffer.unbindFramebuffer();
            BloomUtil.renderBlur(this.bloomFramebuffer.framebufferTexture, this.shadowRadius.get(), this.shadowOffset.get());
        }
    }
}

