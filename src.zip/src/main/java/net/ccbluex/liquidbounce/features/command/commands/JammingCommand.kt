/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.module.modules.exploit.Jamming
import net.ccbluex.liquidbounce.features.module.modules.misc.Teams
import net.ccbluex.liquidbounce.utils.JammingUtils

class JammingCommand : Command("j") {
    override fun execute(args: Array<String>) {
        val Jamming = (LiquidBounce.moduleManager[Jamming::class.java] as Jamming)
        val Teams = (LiquidBounce.moduleManager[Teams::class.java] as Teams)

        mc.netHandler.playerInfoMap.forEach(){
            when(Jamming.Mode.value){
                "Enemy"->{
                    if(!LiquidBounce.fileManager.friendsConfig.isFriend(it.gameProfile.name) && it.playerTeam != mc.thePlayer?.team){
                        JammingUtils.SendMsg(Jamming.IpAddress.value,Jamming.Port.value,Jamming.Message.value,Jamming.name,it.gameProfile.name,it.gameProfile.id.toString())
                    }
                }
                "Team"->{
                    if(it.playerTeam == mc.thePlayer?.team){
                        JammingUtils.SendMsg(Jamming.IpAddress.value,Jamming.Port.value,Jamming.Message.value,Jamming.name,it.gameProfile.name,it.gameProfile.id.toString())
                    }
                }
                "Friend"->{
                    if(LiquidBounce.fileManager.friendsConfig.isFriend(it.gameProfile.name)){
                        JammingUtils.SendMsg(Jamming.IpAddress.value,Jamming.Port.value,Jamming.Message.value,Jamming.name,it.gameProfile.name,it.gameProfile.id.toString())
                    }
                }
                "All"->{
                    JammingUtils.SendMsg(Jamming.IpAddress.value,Jamming.Port.value,Jamming.Message.value,Jamming.name,it.gameProfile.name,it.gameProfile.id.toString())
                }
            }
        }
        chatSyntax("Jamming ==> ${Jamming.Mode.value} Players(${mc.netHandler.playerInfoMap.size - 1})")
        return

        chatSyntax("j <name & all>")
    }
}